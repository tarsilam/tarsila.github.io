// * - Verificar se existe algum Radio preenchido e obter seu valor.

function check_Radio(idElement){

  var selected = document.getElementsByName(idElement);

  var val = "";
	
     for( x = 0; x < selected.length; x++ ){
        if( selected[x].checked )
			val = selected[x].value;
	}
return val;
}


// * - Verificar se existe algum CheckBox preenchido, guardando a quantidade de box preenchidas.

function check_CheckBox(){

	var selected = document.getElementsByName('p_aprender');

	var val = 0;

	for( x = 0; x < selected.length; x++ ){

		if( selected[x].checked )

			val++;
	}

	return val;
}


function validarForm(){


	flagError = "";
	nome = env_form.nome.value;

	sobrenome = env_form.sobrenome.value;

	sexo = check_Radio("sexo");

	data = env_form.data.value;

	rg = env_form.rg.value;

	cpf = env_form.cpf.value;

	rua = env_form.rua.value;

	numero = env_form.numero.value;

	bairro = env_form.bairro.value;

	estado = env_form.estado.value;

	cidade = env_form.cidade.value;

	cep = env_form.cep.value;

	email = env_form.email.value;

	confirmar_email = env_form.confirmar_email.value;

	login = env_form.login.value;

	senha = env_form.senha.value;

	confirmar_senha = env_form.confirmar_senha.value;

	p_webmaster = check_Radio('p_webmaster');

	p_aprender = check_CheckBox();

	comentario = env_form.comentario.value;


	if( verificarFormVazio() )

		flagError = "Formulário não está completamente preenchido.\n";

	if( apenasNumeros() )

		flagError += "Preencha os campos RG, CPF, Número e CEP apenas com números.\n";

	if( apenasLetra() )

		flagError += "Preencha os campos Nome, Sobrenome, Bairro e Cidade apenas com letras.\n";

	if( verificarConfirmacaoEmail() )

		flagError += "Os campos de email não correspondem.\n";

	if( verificarConfirmacaoSenha() )

		flagError += "As senhas não correspondem.\n";

	if( verificarAprender() )

		flagError += "Selecione ao menos uma opção do que deseja aprender.\n";


	if( flagError != "" ) {

		window.alert(flagError);

	}
	else {

		document.env_form.submit();
	}
}

// 1 - Verificar se todos os campos do formulário estão vazios


function verificarFormVazio(){

	if( nome === "" || sobrenome === "" ){

		return 1;
	}	

	else if( sexo.length == 0 ){

		return 1;
	}	

	else if ( data === "" ){
	
	return 1;
    }

	else if ( rg === "" || cpf === ""){

		return 1;
	}	

	else if ( rua === "" ){

		return 1;
	}	

	else if ( numero === "" ){

		return 1;
	}	

	else if ( bairro === "" ){

		return 1;
	}	

	else if ( estado === "" ){

		return 1;
	}	

	else if ( cidade === "" ){

		return 1;
	}	

	else if ( cep === "" ){

		return 1;
	}	

	else if ( email === "" || confirmar_email === ""){

		return 1;
	}	

	else if ( login === "" ){

		return 1;
	}	

	else if ( senha === "" || confirmar_senha === ""){

		return 1;
	}	

	else if ( p_webmaster == 0 ){

		return 1;
	}	

	else if( p_aprender == 0 ){

		return 1;
	}	

	else if ( comentario == "" ){

		return 1;
	}

	return 0;
}

// 2 - Verificar se os campos CPF, RG, Número, CEP, possuem somente números


function apenasNumeros(){

	if(isNaN(rg) || isNaN(cpf) || isNaN(cep) || isNaN( numero )){

		return 1;
	}
	else {

		return 0;
	}	
}

// 3 - Verificar se os campos Nome, Sobrenome, Bairro, Cidade possuem somente letras


function apenasLetra(){

	regAlfa = /[^a-zA-Z_-ç`´^~]/;

	reg = /[0-9]/;

	if(reg.test(nome)){

		return 1;
	}	

	else if(reg.test(sobrenome)){

		return 1;
	}	

	else if(reg.test(bairro)){

		return 1;
	}	

	else if(reg.test(cidade)){

		return 1;
	}	

	return 0;
}

// 4 - Verificar se os campos E-mail e Confirmação de E-mail possuem os mesmo valores


function verificarConfirmacaoEmail(){

	if( email === confirmar_email){

		return 0;
	}
	else{

		return 1;
	}
}

// 5 - Verificar se os campos Senha e Confirmação de Senha possuem os mesmo valores


function verificarConfirmacaoSenha(){

	if( senha === confirmar_senha ){

		return 0;
	}
	else{

		return 1;
	}
}

// 6 - Verificar se o campo "O que você deseja aprender ?" possuí ao menos uma opção selecionada


function verificarAprender(){

	if( p_aprender == 0 ){
       return 0;
	}
	else{

		return 1;
	}
}